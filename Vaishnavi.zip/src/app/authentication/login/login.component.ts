import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent implements OnInit {
  authForm!: FormGroup;
  data: any;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
  ) {
  }

  ngOnInit() {
    this.authForm = this.formBuilder.group({
      Email: ['', Validators.required],
      Password: ['', Validators.required],
    });
  }
  onSubmit() {
    this.data = sessionStorage.getItem('registration');
    this.data = JSON.parse(this.data);
    console.log(this.data);
    let matchedData = this.data.find((x:any) => x.Email === this.authForm.value.Email && x.Password === this.authForm.value.Password);

    if(matchedData) {
      this.router.navigate(['/user/register'])
    }
    else {
      alert("Email and Password is not correct");
    }
  }
}

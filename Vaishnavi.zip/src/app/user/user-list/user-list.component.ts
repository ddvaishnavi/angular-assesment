import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrl: './user-list.component.scss'
})
export class UserListComponent implements OnInit{
  userList: any = [];

  constructor() {}

  ngOnInit(): void {
    let data: any = sessionStorage.getItem('userList');
    this.userList = JSON.parse(data);
    console.log(this.userList);
  }

  delete(index: number) {
    this.userList.splice(index, 1);
    sessionStorage.setItem('userList', JSON.stringify(this.userList));

    setTimeout(() => {
      alert('User deleted successfully');
    }, 500);
  }

}

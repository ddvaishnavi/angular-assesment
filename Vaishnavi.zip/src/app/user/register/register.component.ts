import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.scss'
})
export class RegisterComponent implements OnInit {
  userList: any[] = [];
  registerForm!: FormGroup;
  id: any = 100;
  userid: any;
  userData: any;

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.form();
    let data: any = sessionStorage.getItem('userList');
    this.userList = JSON.parse(data) || [];

    if (this.route.params) {
      this.route.params.subscribe((param) => {
        this.userid = param['id'];
        if(this.userList){
          let lastData = this.userList[this.userList.length - 1];
          this.id = lastData.id;
          this.userData = this.userList.find((x: any) => x.id == this.userid);
        }
    
        this.form()
      });

    }

  }

  form() {
    this.registerForm = this.formBuilder.group({
      Name: [this.userid ? this.userData.Name : ''],
      Email: [this.userid ? this.userData.Email : ''],
      Phone: [this.userid ? this.userData.Phone : '']
    });
  }


  onSubmit() {
    console.log(this.registerForm.value);
    if (!this.userid) {
      let data = {
        ...this.registerForm.value,
        id: ++this.id
      }
      console.log(data);
      this.userList.push(data);
    }
    else {
      let data = {
        ...this.registerForm.value,
        id: this.userid
      }
      console.log(data);
      let index = this.userList.findIndex((x: any) => x.id == this.userid);

      this.userList.splice(index, 1, data);
    }
    sessionStorage.setItem('userList', JSON.stringify(this.userList));
    this.registerForm.reset();
    this.router.navigate(['/user/register'])

  }
}
